#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Jan 26 19:34:05 2026

@author: adrian
"""

# app.py
import os
import setup
import engine
from flask import Flask, render_template, request, json, jsonify, redirect, url_for, session

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

app = Flask(__name__)
app.secret_key = 'some_random_key_here' # Needed to use sessions


# Loads the visual interface
@app.route('/')
def index():
    """
    Serves the main game interface and manages the initial session state.

    This endpoint acts as the entry point for the application. It performs 
    a session check to determine if the user is starting a fresh visit or 
    returning to an active game. If no active session flag is found, any 
    existing 'savegame.json' is deleted to ensure a clean slate for the 
    new game setup.

    Returns:
        Template: The rendered 'index.html' file containing the setup menu 
        and game board container.
    """
    # If 'game_active' is NOT in the session, it's a fresh visit.
    if not session.get('game_active'):
        if os.path.exists('savegame.json'):
            os.remove('savegame.json')
        
    # We leave the flag in the session for the next reload. 
    # If the user closes the tab and comes back, most browsers clear 
    # session cookies, or you can clear it manually later.
    
    # index.html is loaded
    return render_template('index.html')


# Used when starting a new game 
@app.route('/upload', methods=['POST'])
def upload_file():
    """
    Initializes a new jigsaw puzzle game session.

    This endpoint processes the initial setup form submitted by the user.
    It performs the following actions:
    1. Extracts difficulty levels and target board dimensions.
    2. Validates and saves the uploaded image file to the local filesystem.
    3. Triggers the setup module to partition the image into puzzle pieces.
    4. Sets a session flag to maintain the active game state across reloads.

    Form Data (POST):
        difficulty (str): A code ('E', 'M', 'H') representing the puzzle density.
        board_width (int): The current width of the user's browser window.
        board_height (int): The current height of the user's browser window.
        file (File): The source image file to be converted into a puzzle.

    Returns:
        Redirect: Moves the user back to the main game interface upon successful setup.
        HTTP 400: If the file is missing or the selection is invalid.
    """
    # Get the difficulty letter from the dropdown
    level = request.form.get('difficulty')
    
    # Catch the board size from index.html
    b_width = int(request.form.get('board_width'))
    b_height = int(request.form.get('board_height'))
    
    
    # Receive the file
    if 'file' not in request.files:
        return "No file part in the request", 400
    
    file = request.files['file']
    
    if file.filename == '':
        return "No selected file", 400

    if file:
        # Save it to the specific path
        # It's good practice to ensure the directory exists first
        save_path = os.path.join(BASE_DIR, 'static', 'images', 'photo.jpg')
        # save_path = os.path.join('static', 'images', 'photo.jpg')
        file.save(save_path)

        # Pass the level to the setup.py
        setup.create_new_game(save_path, level, (b_width, b_height))
        
        #  Set the session flag
        session['game_active'] = True

        # Tells browser to go back to '/'
        return redirect(url_for('index'))


# Used every time a piece is moved
@app.route('/update_piece', methods=['POST'])
def update():
    """
    Handles the movement and snapping logic for a single puzzle piece.

    This endpoint is called every time a user finishes dragging an individual 
    piece. It updates the piece's coordinates in the engine, which then 
    determines if the piece should snap to neighbors and merge into a group. 
    Finally, it calculates the win state by checking if all pieces have 
    consolidated into a single active group.

    JSON Request Format:
        {
            "r": int,  # Row index of the piece
            "c": int,  # Column index of the piece
            "x": float, # New logical X coordinate
            "y": float  # New logical Y coordinate
        }

    Returns:
        JSON: A dictionary containing:
            - pieces (list): The updated nested list of piece groups.
            - won (bool): True if only one active group remains, False otherwise.
    """
    data = request.json
    # Tell the engine a piece moved
    new_state = engine.handle_move(data['r'], data['c'], data['x'], data['y'])
    
    # Check if the game is won (i.e., all pieces combined into 1 group)
    is_won = sum(1 for group in new_state["pieces"] if len(group) > 0) == 1

    return jsonify({
        "pieces": new_state["pieces"],
        "won": is_won
    })

    
@app.route('/get_pieces')
def get_pieces():
    """
    Retrieves the current puzzle state and configuration from the save file.

    This endpoint reads the 'savegame.json' file, which stores pieces organized 
    by groups. It flattens these groups into a single list of pieces and 
    extracts essential metadata (dimensions, rows, and columns) required 
    for the frontend to initialize or resume a game session.

    Returns:
        JSON: A dictionary containing:
            - pieces (list): Flattened list of all piece objects.
            - pieceW (int): The calculated width of a single piece.
            - pieceH (int): The calculated height of a single piece.
            - photoW (int): The width of the original source image.
            - photoH (int): The height of the original source image.
            - rows (int): Total number of horizontal rows.
            - cols (int): Total number of vertical columns.
        HTTP 404: If no savegame file is found (no active game).
    """
    try:
        with open('savegame.json', 'r') as f:
            data = json.load(f)
            return jsonify({
                "pieces": [p for group in data["pieces"] for p in group],
                "pieceW": data["pW"],
                "pieceH": data["pH"],
                "photoW": data["photoW"],
                "photoH": data["photoH"],
                "rows": data["rows"],
                "cols": data["cols"]
            })
    except FileNotFoundError:
        return jsonify({"error": "No game in progress"}), 404


@app.route('/update_multi', methods=['POST'])
def update_multi():
    """
    Processes coordinates for a batch of moved pieces and evaluates victory.
    
    This handles bulk updates from the multi-selection tool. It processes 
    each move through the engine and then verifies if the total number of 
    active groups on the board has reached 1.
    """
    data = request.json
    pieces_to_update = data.get('pieces', [])
    
    final_state_data = None
    for p in pieces_to_update:
        final_state_data = engine.handle_move(p['r'], p['c'], p['x'], p['y'])
    
    if final_state_data is None:
        return jsonify({"pieces": [], "won": False})

    # Count groups that actually have pieces in them
    active_groups = sum(1 for group in final_state_data["pieces"] if len(group) > 0)
    is_won = active_groups == 1

    return jsonify({
        "pieces": final_state_data["pieces"],
        "won": is_won
    })

if __name__ == '__main__':
    app.run(debug=True)
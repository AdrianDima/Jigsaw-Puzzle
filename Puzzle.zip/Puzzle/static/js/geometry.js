// static/js/geometry.js

// THE EDGE LIBRARY
// Each entry defines the "blueprint" of a side.
const EdgeLibrary = {
    "Classic": {
        type: "curve",
        points: [
            { x: 423.9, y: -142.5 },
            { x: 588.2, y: -148.9 },
            { x: 798.1, y: -157.1 },
            { x: 691.4, y: 41.0 },
            { x: 548.5, y: 306.3 },
            { x: 979.9, y: 306.3 },
            { x: 1411.3, y: 306.3 },
            { x: 1268.4, y: 41.0 },
            { x: 1161.7, y: -157.1 },
            { x: 1371.6, y: -148.9 },
            { x: 1535.9, y: -142.5 },
            { x: 1959.8, y: 0 }
        ]
    },
    "Koch_Level_1": {
        type: "line",
        points: [
            { x: 0.333, y: 0 },    // 1/3 point
            { x: 0.5, y: -0.288 }, // Peak of equilateral triangle
            { x: 0.666, y: 0 },    // 2/3 point
            { x: 1, y: 0 }         // End point
        ]
    },
    "Straight_Line": {
        type: "line",
        points: [
            { x: 1, y: 0 }
        ]
    },
    "Tab_Sharp": {
        type: "combined", // Simple 3-point ear
        points: [
            { x: 0.4, y: 0 },      // End of line 1 / Start of Arc
            { x: 0.5, y: -0.3 },
            { x: 0.6, y: 0 },      // End of Arc / Start of line 2
            { x: 1, y: 0 }         // End of line 2
        ]
    },
    "Tab_Filleted": {
        type: "combined",// Smooth 5-point ear
        points: [
            { x: 2.06, y: 0 },      // End of Line 1 / Start of Fillet 1
            { x: 2.41, y: 0.68 },   // End of Fillet 1 / Start of Arc
            { x: 3.57, y: 0.68 },   // End of Arc / Start of Fillet 2
            { x: 3.92, y: 0 },      // End of Fillet 2 / Start of Line 2
            { x: 5.98, y: 0 }       // End of Line 2
        ]
    }
};

// STATE & SELECTORS - the default selection
const savedShape = localStorage.getItem('selectedPuzzleShape') || "Classic";
let currentEdgeConfig = EdgeLibrary[savedShape];


// The width of the template (based on the last point's X)
const getTemplateWidth = () => currentEdgeConfig.points[currentEdgeConfig.points.length - 1].x;

/**
 * Generates the IN and OUT templates based on the current selection.
 * This is used by getPiecePath to decide which way a tab points.
 */
function getEdgeTemplates() {
    return {
        IN: currentEdgeConfig.points,
        OUT: currentEdgeConfig.points.map(p => ({ x: p.x, y: -p.y }))
    }
};

// The first piece to "visit" an edge will randomly assign it a direction and store
// it. The second piece will see that the edge is already "claimed" and take the
// opposite.
const edgeRegistry = {};

function calculateRelativeM(A, B, M) {
    const dx = B.x - A.x;
    const dy = B.y - A.y;

    // Divide M.x and M.y by the template width to normalize them (0 to 1)
    const width = getTemplateWidth();
    const u = M.x / width;
    const v = M.y / width;

    // Rotation and scaling
    const newMx = A.x + (u * dx - v * dy);
    const newMy = A.y + (u * dy + v * dx);

    return { x: newMx, y: newMy };
};

function jigsawControlPoints(A, B, orientation) {
    // 1. Initialize the array with the starting corner A
    const controlPoints = [A];
    
    // 2. Select which "Stamp" to use from our library.
    // 'orientation' is the string "IN" or "OUT" provided by our Registry.
    const templates = getEdgeTemplates();
    const activeTemplate = templates[orientation];

    // 3. Translate every point M from the template to fit the line A -> B
    activeTemplate.forEach(M => {
        // calculateRelativeM handles the rotation and scaling math
        const transformedPoint = calculateRelativeM(A, B, M);
        controlPoints.push(transformedPoint);
    });

    // 4. Return the full list of 13 points (A + 12 template points)
    return controlPoints;
};

/**
 * Draws the edge.
 */
function generateEdgeString(pts, minX, minY) {
    let str = "";
    if (currentEdgeConfig.type === "line") {
        // Linear path: Connect every point with a straight line (L)
        for (let i = 1; i < pts.length; i++) {
            str += ` L ${pts[i].x - minX} ${pts[i].y - minY}`;
        }
    } else if (currentEdgeConfig.type === "curve") {
        // Curved path: Use Quadratic Bezier (Q)
        // We jump by 2 because each curve needs a control point and an end point.
        for (let i = 1; i < pts.length; i += 2) {
            const controlP = pts[i]; // e.g., P2, P4, P6...
            const endP = pts[i + 1]; // e.g., P3, P5, P7...

            // Q means Quadratic Bézier: ControlPoint, EndPoint
            str += ` Q ${controlP.x - minX} ${controlP.y - minY}, ${endP.x - minX} ${endP.y - minY}`;
        }
    } else { // currentEdgeConfig.type === "combined"
        const p1=pts[1], p2=pts[2], p3=pts[3], p4=pts[4];

        if (pts.length === 5) { // The "Sharp" Ear (4 control points + p0)

            // Combined path: line segment & circle arc & line segment:
            str += ` L ${p1.x - minX} ${p1.y - minY}`;

            // 1. Distance from Arc Start (pts[1]) to Peak (pts[2])
            const dx12 = p2.x - p1.x;
            const dy12 = p2.y - p1.y;
            const chord_squared = dx12 * dx12 + dy12 * dy12;

            // 2. Distance from Arc Start (pts[1]) to Arc End (pts[3]) 
            const dx13 = p3.x - p1.x;
            const dy13 = p3.y - p1.y;
            const base_squared = dx13 * dx13 + dy13 * dy13;

            const radius = chord_squared / Math.sqrt(4 * chord_squared - base_squared);

            // Vector 1: p1 to p2
            const v1x = p2.x - p1.x;
            const v1y = p2.y - p1.y;

            // Vector 2: p1 to p3
            const v2x = p3.x - p1.x;
            const v2y = p3.y - p1.y;

            // The 2D Cross Product (Z-component)
            const crossProduct = (v1x * v2y) - (v1y * v2x);

            // Check if the peak p2 is to the left or right of the line connecting
            // the start p1 and the end p3:
            // If crossProduct > 0, the points are counter-clockwise
            // If crossProduct < 0, the points are clockwise
            const sweep_flag = (crossProduct > 0) ? 0 : 1;

            // Draw Arc
            str += ` A ${radius} ${radius} 0 1 ${sweep_flag} ${p3.x - minX} ${p3.y - minY}`;

            // Draw final line to the end corner
            str += ` L ${p4.x - minX} ${p4.y - minY}`;
        }
        else { // The "Filleted" Ear (5 control points + p0)

            const p0 = pts[0], p5 = pts[5];

            // Perpendicular to P0P1 at P1:
            const per = getPerpendicularAtPoint(p0, p1);

            // Perpendicular bisector of P1P2:
            const perBis1 = getPerpendicularBisector(p1, p2);

            // Intersection / Center of the first fillet:
            const cenFillet1 = solveIntersection(per, perBis1);

            const filletRadius = Math.sqrt((p2.x-cenFillet1.x)**2 + (p2.y-cenFillet1.y)**2);

            // Perpendicular bisector of P2P3:
            const perBis2 = getPerpendicularBisector(p2, p3);

            // Equation of a line through two points: cenFillet1 and P2:
            const centersLine = getLineFromPoints(cenFillet1, p2);

            // Intersection / Center of the Main Ear:
            const cenEar = solveIntersection(perBis2, centersLine);

            const largeRadius = Math.sqrt((p3.x-cenEar.x)**2 + (p3.y-cenEar.y)**2);

            // 1. Determine direction using the Cross Product of the main ear
            const cp = (p3.x - p2.x) * (p4.y - p2.y) - (p3.y - p2.y) * (p4.x - p2.x);
            const mainSweep = (cp > 0) ? 1 : 0;

            // 2. Fillets must be the inverse sweep for the "fillet" effect
            const filletSweep = (mainSweep === 1) ? 0 : 1;

            // Line 1 to the start of the first fillet
            str += ` L ${p1.x - minX} ${p1.y - minY}`;

            // Fillet 1 (Concave transition)
            str += ` A ${filletRadius} ${filletRadius} 0 0 ${filletSweep} ${p2.x - minX} ${p2.y - minY}`;

            // Main Ear (The big bulb)
            str += ` A ${largeRadius} ${largeRadius} 0 1 ${mainSweep} ${p3.x - minX} ${p3.y - minY}`;

            // Fillet 2 (Concave transition back to base)
            str += ` A ${filletRadius} ${filletRadius} 0 0 ${filletSweep} ${p4.x - minX} ${p4.y - minY}`;

            // Final Line 2 to the corner
            str += ` L ${p5.x - minX} ${p5.y - minY}`;
        }
    }
    return str;
};

// Equation of a line through two points:
function getLineFromPoints(p1, p2) {
    const dx = p2.x - p1.x;
    const dy = p2.y - p1.y;

    if (dx === 0) {
        return { isVertical: true, x: p1.x, m: Infinity, c: null };
    }

    const m = dy / dx;
    const c = p1.y - (m * p1.x);
    return { isVertical: false, m: m, c: c };
};

// Find the perpendicular bisector to P1P2:
function getPerpendicularBisector(p1, p2) {
    const midX = (p1.x + p2.x) / 2;
    const midY = (p1.y + p2.y) / 2;
    
    const dx = p2.x - p1.x;
    const dy = p2.y - p1.y;

    // If P1P2 is horizontal, the perpendicular bisector is vertical:
    if (dy === 0) {
        return { isVertical: true, x: midX, m: Infinity, c: null };
    }
    
    // If P1P2 is vertical, the perpendicular bisector is horizontal (m = 0):
    if (dx === 0) {
        return { isVertical: false, m: 0, c: midY };
    }

    const mPerp = -dx / dy;
    const cPerp = midY - (mPerp * midX);
    return { isVertical: false, m: mPerp, c: cPerp };
};

// Find the perpendicular to P1P2 at P2:
function getPerpendicularAtPoint(p1, p2) {
    const dx = p2.x - p1.x;
    const dy = p2.y - p1.y;

    // If P1P2 is horizontal, perpendicular is vertical:
    if (dy === 0) {
        return { isVertical: true, x: p2.x, m: Infinity, c: null };
    }
    // If P1P2 is vertical, perpendicular is horizontal (m = 0):
    if (dx === 0) {
        return { isVertical: false, m: 0, c: p2.y };
    }

    const mPerp = -dx / dy;
    const cPerp = p2.y - (mPerp * p2.x);
    return { isVertical: false, m: mPerp, c: cPerp };
};

// Intersection point of two lines
// y = m * x + c
// Expects line objects: { m, c, isVertical, x }
// m = slope
// c = the point where the line crosses the Y-axis.
// x = the horizontal position of a vertical line.
function solveIntersection(l1, l2) {

    let x, y;

    // Handle cases where one line is vertical
    if (l1.isVertical) {
        x = l1.x;
        y = l2.m * x + l2.c;
    } 
    else if (l2.isVertical) {
        x = l2.x;
        y = l1.m * x + l1.c;
    } 
    // Handle cases where one line is horizontal (m = 0)
    // (Note: This is technically covered by the linear case below, 
    // but explicit handling prevents precision issues)
    else if (l1.m === 0) {
        y = l1.c;
        x = (y - l2.c) / l2.m;
    }
    else if (l2.m === 0) {
        y = l2.c;
        x = (y - l1.c) / l1.m;
    }
    // 4. Standard Linear vs. Linear intersection
    else {
        // m1 * x + c1 = m2 * x + c2
        // x * (m1 - m2) = c2 - c1
        x = (l2.c - l1.c) / (l1.m - l2.m);
        y = l1.m * x + l1.c;
    }

    return { 
        x: Number(x.toFixed(4)), 
        y: Number(y.toFixed(4)) 
    };
};

function getPiecePath(r, c, matrix, rows, cols, minX, minY) {
    // 1. Map the grid coordinates for the 4 corners
    const coords = [
        {r: r,   c: c},     // Top-Left
        {r: r,   c: c+1},   // Top-Right
        {r: r+1, c: c+1},   // Bottom-Right
        {r: r+1, c: c}      // Bottom-Left
    ];

    const nodes = coords.map(pos => matrix[pos.r][pos.c]);
    
    // Move to the first corner
    let path = `M ${nodes[0].x - minX} ${nodes[0].y - minY}`;

    for (let i = 0; i < 4; i++) {
        const A_pos = coords[i];
        const B_pos = coords[(i + 1) % 4];
        const A = nodes[i];
        const B = nodes[(i + 1) % 4];

        // Border logic
        const isTopEdge = (i === 0 && r === 0);
        const isRightEdge = (i === 1 && c === cols - 1);
        const isBottomEdge = (i === 2 && r === rows - 1);
        const isLeftEdge = (i === 3 && c === 0);

        if (isTopEdge || isRightEdge || isBottomEdge || isLeftEdge) {
            path += ` L ${B.x - minX} ${B.y - minY}`;
        } else {
            // Now A_pos and B_pos are defined!
            const orientation = getEdgeOrientation(A_pos.r, A_pos.c, B_pos.r, B_pos.c);
            const pts = jigsawControlPoints(A, B, orientation); 
            path += generateEdgeString(pts, minX, minY);
        }
    }
    return path + " Z";
};

function getEdgeOrientation(r1, c1, r2, c2) {
    // 1. Create a unique ID that is the same regardless of order
    // Sort the coordinates so (A,B) and (B,A) produce the same key
    // If the rows are the same r1 == r2, sort after columns c1 and c2:
    const pts = [[r1, c1], [r2, c2]].sort((a, b) => a[0] - b[0] || a[1] - b[1]);
    const edgeId = `r${pts[0][0]}c${pts[0][1]}-r${pts[1][0]}c${pts[1][1]}`;

    // 2. Check if we've already decided an orientation for this edge
    if (edgeRegistry[edgeId] !== undefined) {
        // We are the second piece visiting this edge!
        // We must return the OPPOSITE of what the first piece used.
        return edgeRegistry[edgeId] === 'OUT' ? 'IN' : 'OUT';
    } else {
        // First piece here! Pick one randomly and save it.
        const choice = Math.random() > 0.5 ? 'OUT' : 'IN';
        edgeRegistry[edgeId] = choice;
        return choice;
    }
};

/**
 * Creates a random jitter within a circle.
 * @param {number} x - The base X coordinate.
 * @param {number} y - The base Y coordinate.
 * @param {number} radius - The maximum wobble radius (R).
 */
function pointGenerator(x, y, radius) {
    let r = radius * Math.sqrt(Math.random());
    let theta = Math.random() * 2 * Math.PI;

    return {
        x: x + r * Math.cos(theta),
        y: y + r * Math.sin(theta)
    };
};
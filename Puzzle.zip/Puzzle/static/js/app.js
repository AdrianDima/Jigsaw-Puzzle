// static/js/app.js

/**
 * JIGSAW PUZZLE GAME CONTROLLER
 * * This file manages the client-side game logic, including:
 * - Rendering puzzle pieces based on server data.
 * - Handling mouse interactions (dragging, dropping, and multi-selection).
 * - Communicating with the Flask back-end (/update_piece, /update_multi, /get_pieces).
 * - Triggering the win state UI.
 */


// ==========================================
// 1. GLOBAL STATE & CONFIGURATION
// ==========================================
let rows, cols, pieceW, pieceH, photoW, photoH, R; // R is the "Wobble Radius" (10% of the average piece dimension)
let puzzleMatrix = null;
let draggedPiece = null;
let draggedGroup = [];
let offsetX = 0;
let offsetY = 0;
let highestZ = 10;
let selectedPieces = new Set();
let isSelecting = false;
let selectionStartX = 0;
let selectionStartY = 0;
let pieceBuffer;

// ==========================================
// 2. UPLOAD & SETUP LOGIC
// ==========================================
document.getElementById('file-input').addEventListener('change', function(e) {
    const file = e.target.files[0];
    const errorDiv = document.getElementById('client-error');
    const uploadButton = document.getElementById('upload-btn');

    if (!file) return;

    const img = new Image();
    const objectUrl = URL.createObjectURL(file);

    img.onload = function() {
        const w = this.width;
        const h = this.height;
        const ratio = w / h;

        let errorMessage = "";

        if (ratio < 0.5) {
            errorMessage = "⚠️ This photo is too tall and skinny. Please choose a wider one.";
        } else if (ratio > 2.0) {
            errorMessage = "⚠️ This photo is too wide and long. Please choose a taller one.";
        }

        if (errorMessage) {
            errorDiv.textContent = errorMessage;
            errorDiv.style.display = "block";
            uploadButton.disabled = true;
            uploadButton.style.opacity = "0.5";
            uploadButton.style.cursor = "not-allowed";
        } else {
            errorDiv.style.display = "none";
            uploadButton.disabled = false;
            uploadButton.style.opacity = "1";
            uploadButton.style.cursor = "pointer";
        }
        
        URL.revokeObjectURL(objectUrl); // Clean up memory
    };

    img.src = objectUrl;
});

document.getElementById('upload-btn').addEventListener('click', function() {

    // Capture the user's choice from the radio buttons
    const selectedShape = document.querySelector('input[name="edge_style"]:checked').value;

    // Save it to localStorage (this survives page refreshes)
    localStorage.setItem('selectedPuzzleShape', selectedShape);

    console.log("Button clicked!");
    
    const bWidth = window.innerWidth;
    const bHeight = window.innerHeight;

    document.getElementById('form_w').value = Math.round(bWidth);
    document.getElementById('form_h').value = Math.round(bHeight);
    
    console.log("Dimensions set to:", bWidth, bHeight);

    // Explicitly target the form by its ID and call submit
    const form = document.getElementById('upload-form');
    form.submit(); 
    console.log("Form submitted!");
});

// ==========================================
// 3. CORE GAME ENGINE (Loading & Rendering)
// ==========================================
async function loadGame() {
    const response = await fetch('/get_pieces');
    if (!response.ok) return; // Don't try to load if there's no game

    if (response.status === 404) {
        document.getElementById('setup-menu').style.display = 'block'; // Ensure menu is visible
        document.getElementById('game-board').style.display = 'none';
        return;
    };

    if (response.status === 200) {
        // Success
        document.getElementById('game-board').style.display = 'block';
    };

    const data = await response.json(); // This is now the "package"

    // Game exists! Hide the menu and show the full-screen board.
    // document.getElementById('setup-menu').style.display = 'none';
    const board = document.getElementById('game-board');
    board.style.display = 'block';

    // We find the form and hide it because the game has started
    const uploadForm = document.querySelector('form');
    uploadForm.classList.add('hidden');

    board.innerHTML = ''; // Clear the board before adding new pieces

    // Use the values Python calculated
    rows = data.rows;
    cols = data.cols;
    pieceW = data.pieceW;
    pieceH = data.pieceH;
    photoW = data.photoW; // Actual image width
    photoH = data.photoH; // Actual image height

    // Get the style the user picked in the menu, defaulting to 'Classic' if none is found
    const selectedStyle = localStorage.getItem('selectedPuzzleShape') || "Classic";

    // Determine the Wobble (R) based on style
    // Classic, Straight and Koch styles look better with "jitter"
    if (selectedStyle === "Tab_Sharp" || selectedStyle === "Tab_Filleted") {
        R = 0; 
    } else {
        R = 0.1 * (pieceW + pieceH) / 2; // Default 10% wobble
    }

    // Assign to the global variable
    puzzleMatrix = anchorMatrixGenerator();
    
    data.pieces.forEach(p => {
        const div = document.createElement('div');
        div.className = 'piece';

        div.dataset.r = p.r;
        div.dataset.c = p.c;

        // When use the dataset object, JavaScript automatically removes the dashes 
        // and capitalizes the next letter.
        // So, data-group-id (HTML) becomes groupId (JavaScript)
        div.setAttribute('data-group-id', p.group_id);

        // For any piece at a specific row (r) and column (c), its shape is defined
        // by these four points from the matrix:
        const tl = puzzleMatrix[p.r][p.c]; // Top-Left
        const tr = puzzleMatrix[p.r][p.c+1]; // Top-Right
        const br = puzzleMatrix[p.r+1][p.c+1]; // Bottom-Right
        const bl = puzzleMatrix[p.r+1][p.c]; // Bottom-Left

        // The base area of the Div:
        const rawMinX = Math.min(tl.x, bl.x);
        const rawMinY = Math.min(tl.y, tr.y);
        const rawMaxX = Math.max(tr.x, br.x);
        const rawMaxY = Math.max(bl.y, br.y);

        // The 'buffer' allows the piece <div> to be larger than the logical grid.
        // This ensures that 'tabs' or 'notches' sticking out of the piece 
        // are not cut off by the edges of the <div>.
        pieceBuffer = (pieceW + pieceH) / 2 * 0.5;

        // Only apply buffer if the piece is NOT on that specific border
        const bufferL = (p.c === 0) ? 0 : pieceBuffer;          // Left side
        const bufferT = (p.r === 0) ? 0 : pieceBuffer;          // Top side
        const bufferR = (p.c === cols - 1) ? 0 : pieceBuffer;   // Right side
        const bufferB = (p.r === rows - 1) ? 0 : pieceBuffer;   // Bottom side

        // The new Min/Max coordinates using specific side buffers
        const minX = rawMinX - bufferL;
        const minY = rawMinY - bufferT;

        // Set the Div size to include the buffer:
        div.style.width = `${(rawMaxX - rawMinX) + bufferL + bufferR}px`;
        div.style.height = `${(rawMaxY - rawMinY) + bufferT + bufferB}px`;

        // Add wobble offset calculation:
        const wobbleX = rawMinX - (p.c * pieceW);
        const wobbleY = rawMinY - (p.r * pieceH);                

        // Position the div on the board using the specific Top/Left buffers:
        div.style.left = `${(p.x + wobbleX) - bufferL}px`;
        div.style.top = `${(p.y + wobbleY) - bufferT}px`;

        // The Image
        div.style.backgroundImage = `url('/static/images/photo.jpg?t=${new Date().getTime()}')`;
        div.style.backgroundSize = `${photoW}px ${photoH}px`;

        // Align the image: The image always starts at the logical rawMinX, 
        // so the offset is exactly the left/top buffer we used.
        div.style.backgroundPosition = `-${rawMinX - bufferL}px -${rawMinY - bufferT}px`;

        // The path relative to the buffered minX/minY:
        const piecePath = getPiecePath(p.r, p.c, puzzleMatrix, rows, cols, minX, minY);
        div.style.clipPath = `path('${piecePath}')`;

        //div.addEventListener('mousedown', startDrag);
        div.addEventListener('mousedown', (e) => {
            e.stopPropagation(); // Prevents the event from reaching the board's mousedown listener
            
            if (!selectedPieces.has(e.target)) {
                selectedPieces.forEach(p => p.style.outline = '');
                selectedPieces.clear();
            }
            startDrag(e);
        });

        board.appendChild(div);
    });
};

// ==========================================
// 4. INTERACTION HANDLERS (Drag, Select, Mouse)
// ==========================================
function startDrag(e) {
    draggedPiece = e.target;
    const r = parseInt(draggedPiece.dataset.r);
    const c = parseInt(draggedPiece.dataset.c);

    // Specific buffers for this piece:
    const bufferL = (c === 0) ? 0 : pieceBuffer;
    const bufferT = (r === 0) ? 0 : pieceBuffer;

    // Subtract the buffer from the offset so the mouse 
    // "thinks" it's grabbing the logical corner, not the buffered edge.
    offsetX = e.clientX - (parseInt(draggedPiece.style.left) + bufferL);
    offsetY = e.clientY - (parseInt(draggedPiece.style.top) + bufferT);


    if (selectedPieces.has(draggedPiece)) {
        draggedGroup = Array.from(selectedPieces);
    } else {
        // Get the group ID of the piece you just clicked
        const currentGroupId = draggedPiece.dataset.groupId;
        // Find all pieces in that group
        draggedGroup = document.querySelectorAll(`.piece[data-group-id="${currentGroupId}"]`);
    }

    // Increment the global counter once
    highestZ++;

    // Bring the whole group to be on top of everything else:
    draggedGroup.forEach(p => {
        p.style.zIndex = highestZ;
    });

    // Initialize lastX and lastY so the first move has a reference point
    draggedPiece.dataset.lastX = e.clientX - offsetX;
    draggedPiece.dataset.lastY = e.clientY - offsetY;
};

window.addEventListener('mousemove', (e) => {
    if (isSelecting) {
        const currentX = e.clientX;
        const currentY = e.clientY;

        const left = Math.min(selectionStartX, currentX);
        const top = Math.min(selectionStartY, currentY);
        const width = Math.abs(currentX - selectionStartX);
        const height = Math.abs(currentY - selectionStartY);

        const selectionBox = document.getElementById('selection-box');
        selectionBox.style.left = `${left}px`;
        selectionBox.style.top = `${top}px`;
        selectionBox.style.width = `${width}px`;
        selectionBox.style.height = `${height}px`;
        return;
    };

    if (!draggedPiece) return;

    const r = parseInt(draggedPiece.dataset.r);
    const c = parseInt(draggedPiece.dataset.c);

    // Calculate the "Logical" position for the piece under the mouse
    const logicalX = e.clientX - offsetX;
    const logicalY = e.clientY - offsetY;

    // Calculate the "Shift" (How much did the anchor piece move?)
    const dx = logicalX - parseInt(draggedPiece.dataset.lastX || 0);
    const dy = logicalY - parseInt(draggedPiece.dataset.lastY || 0);

    // Move the whole group
    draggedGroup.forEach(p => {
        const currentLeft = parseInt(p.style.left || 0);
        const currentTop = parseInt(p.style.top || 0);

        p.style.left = `${currentLeft + dx}px`;
        p.style.top = `${currentTop + dy}px`;
    });

    // Save the current position to use for the next move's calculation
    draggedPiece.dataset.lastX = logicalX;
    draggedPiece.dataset.lastY = logicalY;
});

window.addEventListener('mouseup', async () => {
    /* =========================================================================
     * SITUATION 1: DRAGGING A TEMPORARY SELECTION BOX
     * =========================================================================
     * The player used the box tool to temporarily highlight random pieces,
     * grabbed one, and dragged them all together.
     */
    if (isSelecting) {
        isSelecting = false;
        const selectionBox = document.getElementById('selection-box');
        const rect = selectionBox.getBoundingClientRect();
        selectionBox.classList.add('hidden');

        // Clear previous selection
        selectedPieces.forEach(p => p.style.outline = '');
        selectedPieces.clear();

        const pieces = document.querySelectorAll('.piece');
        pieces.forEach(p => {
            // 1. Get the visual position from the style
            const visualLeft = parseInt(p.style.left);
            const visualTop = parseInt(p.style.top);
            
            // 2. Calculate the "Logical" (unbuffered) top-left corner
            const r = parseInt(p.dataset.r);
            const c = parseInt(p.dataset.c);
            const bL = (c === 0) ? 0 : pieceBuffer;
            const bT = (r === 0) ? 0 : pieceBuffer;

            const logicalLeft = visualLeft + bL;
            const logicalTop = visualTop + bT;

            // 3. Check collision using pieceW and pieceH (ignoring buffers)
            // We check if the selection rect overlaps the logical piece square
            if (rect.left < (logicalLeft + pieceW) && 
                rect.right > logicalLeft &&
                rect.top < (logicalTop + pieceH) && 
                rect.bottom > logicalTop) {
                
                selectedPieces.add(p);
                p.style.outline = '3px solid #00ff00';
            }
        });
        return;
    }

    /* =========================================================================
     * SITUATION 2: DRAGGING A SINGLE PIECE OR AN ALREADY BONDED CLUSTER
     * =========================================================================
     * The player clicked directly on a single standalone piece, or clicked on a 
     * cluster of pieces that have already snapped and locked together permanently 
     * during gameplay, and dragged them.
     */
    if (!draggedPiece) return;

    // 1. Screen Boundary Correction (Keep pieces inside the window)
    let minLogicalX = Infinity, maxLogicalX = -Infinity;
    let minLogicalY = Infinity, maxLogicalY = -Infinity;

    draggedGroup.forEach(p => {
        const pr = parseInt(p.dataset.r);
        const pc = parseInt(p.dataset.c);
        const bL = (pc === 0) ? 0 : pieceBuffer;
        const bT = (pr === 0) ? 0 : pieceBuffer;

        const lpX = parseInt(p.style.left) + bL;
        const lpY = parseInt(p.style.top) + bT;

        if (lpX < minLogicalX) minLogicalX = lpX;
        if (lpX + pieceW > maxLogicalX) maxLogicalX = lpX + pieceW;
        if (lpY < minLogicalY) minLogicalY = lpY;
        if (lpY + pieceH > maxLogicalY) maxLogicalY = lpY + pieceH;
    });

    let shiftX = 0, shiftY = 0;
    if (minLogicalX < 0) shiftX = -minLogicalX;
    else if (maxLogicalX > window.innerWidth) shiftX = window.innerWidth - maxLogicalX;

    if (minLogicalY < 0) shiftY = -minLogicalY;
    else if (maxLogicalY > window.innerHeight) shiftY = window.innerHeight - maxLogicalY;
    
    draggedGroup.forEach(p => {
        p.style.left = `${parseInt(p.style.left) + shiftX}px`;
        p.style.top = `${parseInt(p.style.top) + shiftY}px`;
    });

    // Determine if the drag action was for an ad-hoc multi-selection set
    const isMultiSelectionDrag = (selectedPieces.size > 0 && selectedPieces.has(draggedPiece));

    let fetchUrl = '/update_piece';
    let payload = {};

    if (isMultiSelectionDrag) {
        /* =========================================================================
         * SITUATION 1: DRAGGING A TEMPORARY SELECTION BOX
         * =========================================================================
         * Loop through every piece currently moving in the visual group, calculate 
         * its individual layout coordinates, and send a massive collection array 
         * to the '/update_multi' batch endpoint so the server commits all of them.
         */
        fetchUrl = '/update_multi';
        payload = { pieces: [] };

        draggedGroup.forEach(p => {
            const r = parseInt(p.dataset.r);
            const c = parseInt(p.dataset.c);
            const bL = (c === 0) ? 0 : pieceBuffer;
            const bT = (r === 0) ? 0 : pieceBuffer;

            const tl = puzzleMatrix[r][c];
            const bl = puzzleMatrix[r+1][c];
            const rawMinX = Math.min(tl.x, bl.x);
            const tr = puzzleMatrix[r][c+1];
            const rawMinY = Math.min(tl.y, tr.y);

            const wobbleX = rawMinX - (c * pieceW);
            const wobbleY = rawMinY - (r * pieceH);

            const currentX = parseInt(p.style.left) + bL;
            const currentY = parseInt(p.style.top) + bT;

            payload.pieces.push({
                r: r,
                c: c,
                x: currentX - wobbleX,
                y: currentY - wobbleY
            });
        });
    } else {
        /* =========================================================================
         * SITUATION 2: DRAGGING A SINGLE PIECE OR AN ALREADY BONDED CLUSTER
         * =========================================================================
         * Extract the coordinates of just the one "Anchor Piece" being held by the 
         * hand. We send this streamlined payload to the '/update_piece' endpoint. 
         * The Python backend moves this piece, smoothly shifts its connected group 
         * members relative to it, and snaps the whole rigid cluster onto the board.
         */
        fetchUrl = '/update_piece';
        
        const r_anchor = parseInt(draggedPiece.dataset.r);
        const c_anchor = parseInt(draggedPiece.dataset.c);

        const bL_anchor = (c_anchor === 0) ? 0 : pieceBuffer;
        const bT_anchor = (r_anchor === 0) ? 0 : pieceBuffer;

        const tl_anchor = puzzleMatrix[r_anchor][c_anchor];
        const bl_anchor = puzzleMatrix[r_anchor+1][c_anchor];
        const rawMinX_anchor = Math.min(tl_anchor.x, bl_anchor.x);
        const tr_anchor = puzzleMatrix[r_anchor][c_anchor+1];
        const rawMinY_anchor = Math.min(tl_anchor.y, tr_anchor.y);

        const wobbleX_anchor = rawMinX_anchor - (c_anchor * pieceW);
        const wobbleY_anchor = rawMinY_anchor - (r_anchor * pieceH);

        const currentX_anchor = parseInt(draggedPiece.style.left) + bL_anchor;
        const currentY_anchor = parseInt(draggedPiece.style.top) + bT_anchor;

        payload = {
            r: r_anchor,
            c: c_anchor,
            x: currentX_anchor - wobbleX_anchor,
            y: currentY_anchor - wobbleY_anchor
        };
    }

    // Clear the visual outline and the selection set
    selectedPieces.forEach(p => p.style.outline = '');
    selectedPieces.clear();

    // Clean up global drag variables before firing the network request
    draggedPiece = null;
    draggedGroup = [];

    // 3. Send to Server
    try {
        const response = await fetch(fetchUrl, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        });
        if (response.ok) {
            const updatedState = await response.json();
            
            // 1. Always update the board positions first (snapping pieces together)
            renderBoard(updatedState.pieces);

            // 2. Then check the win flag returned by the server
            if (updatedState.won === true) {
                const winMsg = document.getElementById('win-message');
                winMsg.style.display = 'block';
                winMsg.style.zIndex = "20000"; 
            }
        }
        
    } catch (error) {
        console.error("Failed to update pieces:", error);
    }
});

function renderBoard(piecesList) {
    // piecesList is the list of groups so we flatten it to iterate over every piece
    const allPieces = piecesList.flat();

    allPieces.forEach(p => {
        // Find the specific <div> for this piece using its row and column
        const div = document.querySelector(`.piece[data-r="${p.r}"][data-c="${p.c}"]`);
        if (div) {
            const bufferL = (p.c === 0) ? 0 : pieceBuffer;
            const bufferT = (p.r === 0) ? 0 : pieceBuffer;

            // Compute wobble offsets for the piece
            const tl = puzzleMatrix[p.r][p.c];
            const tr = puzzleMatrix[p.r][p.c+1];
            const bl = puzzleMatrix[p.r+1][p.c];
            const br = puzzleMatrix[p.r+1][p.c+1];

            const rawMinX = Math.min(tl.x, bl.x);
            const rawMinY = Math.min(tl.y, tr.y);

            const wobbleX = rawMinX - (p.c * pieceW);
            const wobbleY = rawMinY - (p.r * pieceH);

            // Update the visual position by adding the wobble offset
            div.style.left = `${(p.x + wobbleX) - bufferL}px`;
            div.style.top = `${(p.y + wobbleY) - bufferT}px`;

            // Update the group_id in the HTML data attribute
            div.dataset.groupId = p.group_id;
        }
    });
};


// The Anchor Matrix Generator
// This builds the "Skeleton" of the puzzle
function anchorMatrixGenerator() {
    let anchors = [];

    for (let i = 0; i <= rows; i++) {
        let currentRow = [];
        
        for (let j = 0; j <= cols; j++) {
            // These are the "Perfect" grid coordinates
            const idealX = j * pieceW;
            const idealY = i * pieceH;

            // BORDER CHECK: Is the point on any of the 4 edges?
            if (i === 0 || i === rows || j === 0 || j === cols) {
                // If on the border, keep the point perfectly straight
                currentRow.push({ x: idealX, y: idealY });
            } 
            else {
                // If inside, call the generator to wobble the point
                const jitteredPoint = pointGenerator(idealX, idealY, R);
                currentRow.push(jitteredPoint);
            }
        }
        // Add the row of points to the master matrix
        anchors.push(currentRow);
    }
    return anchors;
};

window.addEventListener('load', function() {
    console.log("Page finished loading. Setting up...");
    
    // Load the game pieces
    loadGame();
    
    console.log("Initialization complete");
});

document.getElementById('game-board').addEventListener('mousedown', (e) => {
    
    // Prevent default browser behavior (text selection or drag)
    e.preventDefault();

    isSelecting = true;
    selectionStartX = e.clientX;
    selectionStartY = e.clientY;

    const selectionBox = document.getElementById('selection-box');
    selectionBox.classList.remove('hidden');
    selectionBox.style.left = `${selectionStartX}px`;
    selectionBox.style.top = `${selectionStartY}px`;
    selectionBox.style.width = '0px';
    selectionBox.style.height = '0px';

    // Clear previous selection if clicking on the background
    selectedPieces.forEach(p => p.style.outline = '');
    selectedPieces.clear();
});
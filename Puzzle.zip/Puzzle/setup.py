#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Mar 10 12:46:39 2026

@author: adrian
"""

# setup.py
from PIL import Image
import json
import random

def create_new_game(image_path, level, board_size):
    """
    Initializes a new jigsaw puzzle game.

    This function loads the source image, resizes it to fit the board dimensions, 
    divides the image into a grid based on the specified difficulty level, and 
    generates the initial scrambled pieces with their respective groups, positions, 
    and dimensions. It then saves the initial state to 'savegame.json'.

    Args:
        image_path (str): The file path to the source image.
        level (str): The difficulty level of the puzzle, represented by a 
                     string key (e.g., 'E' for Easy, 'M' for Medium, 'H' for Hard).
        board_size (tuple of int): A tuple representing the maximum board 
                                   dimensions (width, height) in pixels.

    Returns:
        list: The initial scrambled layout (or the board state) of the puzzle pieces.
    """
    img = Image.open(image_path)
    w, h = img.size

    # Map difficulty target N
    difficulty_map = {"E": 24, "M": 96, "H": 216}
    target_n = difficulty_map.get(level, 96)

    # Scaling (95% logic)
    # If the image is smaller than or equal to 95% of the board, it should
    # not be scaled. If it is larger, it should be scaled so that the largest
    # dimension of the image is 80% of the board.
    allowed_size = 0.8
    scale = min(allowed_size * board_size[0] / w, allowed_size * board_size[1] / h)
    if scale < 1:
        img = img.resize((int(w * scale), int(h * scale)), Image.Resampling.LANCZOS)
    
    photo_w, photo_h = img.size

    # 4. The "Best Fit" Hunt (the 0.95 ratio logic):
    # We want the pieces to be approximately square. For this, the
    # Piece Aspect Ratio must be as close to 1.0 as possible.
    # We chose a ratio of at least 0.95
    best_r, best_c = 0, 0
    best_ratio = 0
    current_n = target_n
    
    # We loop until we find a grid that satisfies the 0.95 requirement
    # but we cap it so it doesn't spiral into 1000 pieces
    while best_ratio < 0.95 and current_n < target_n * 2:
        # Check rows around the ideal mathematical center
        ideal_r = (current_n / (photo_w / photo_h))**0.5
        # We check the row count just below and just above our "ideal" number
        # (e.g., if ideal is 6.5, we check 5, 6, and 7).
        for r_test in range(max(1, int(ideal_r) - 1), int(ideal_r) + 2):
            c_test = max(1, round(current_n / r_test))
            
            pW, pH = photo_w / c_test, photo_h / r_test
            ratio = min(pW/pH, pH/pW)
            
            if ratio > best_ratio:
                best_ratio = ratio
                best_r, best_c = r_test, c_test
        
        if best_ratio >= 0.95:
            break
        current_n += 1
        
    pW = photo_w // best_c
    pH = photo_h // best_r

    # Create the Pieces Data...
    scrambled = []
    group_wishlists = []
    index = 0
    
    # Define the working space (50% of board width)
    workspace_ratio = 0.50 

    # Calculate side width based on the remaining space
    side_ratio = (1.0 - workspace_ratio) / 2
    
    left_boundary = int(board_size[0] * side_ratio)
    right_boundary = int(board_size[0] * (1.0 - side_ratio))
    
    for r in range(best_r):
        for c in range(best_c):
            
            # Decide: Left side or Right side?
            if random.random() < 0.5:
                # Left Bin: 0 to 25%
                x_pos = random.randint(0, left_boundary - pW)
            else:
                # Right Bin: 75% to 100%
                x_pos = random.randint(right_boundary, board_size[0] - pW)
            
            y_pos = random.randint(0, board_size[1] - pH)
            # If a piece has an empty free_sides list, you know it is "buried"
            # inside a group and you don't even need to check its neighbors anymore.
            piece_data = {
                "r": r, "c": c, 
                "x": x_pos, 
                "y": y_pos,
                "group_id": index
            }
            scrambled.append([piece_data]) # Each piece starts in its own group list
            
            # Build the Wishlist for this specific group
            wishlist = []
            # Check North
            if r > 0: wishlist.append([r - 1, c])
            # Check South
            if r < best_r - 1: wishlist.append([r + 1, c])
            # Check West
            if c > 0: wishlist.append([r, c - 1])
            # Check East
            if c < best_c - 1: wishlist.append([r, c + 1])
            
            group_wishlists.append(wishlist)
            
            index += 1
            
    # Save the initial game state, wishlists, and board dimensions:
    with open('savegame.json', 'w') as f:
        json.dump({
            "pieces": scrambled,
            "wishlists": group_wishlists, # Save the pre-calculated neighbors
            "pW": pW, 
            "pH": pH,
            "photoW": photo_w,
            "photoH": photo_h,
            "rows": best_r,
            "cols": best_c
        }, f)

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Mar 10 17:13:20 2026

@author: adrian
"""

# engine.py
import json

def load_state():
    with open('savegame.json', 'r') as f:
        return json.load(f)

def save_state(data):
    with open('savegame.json', 'w') as f:
        json.dump(data, f)

def handle_move(anchor_r, anchor_c, new_x, new_y):
    """
    Handles the movement and snapping of a puzzle group.

    This function updates the positions of all pieces in the group being moved 
    based on the anchor piece's new screen coordinates. It then checks the group's 
    wishlist to see if it is adjacent to any other pieces, and if so, checks if it is 
    close enough to snap. If a snap condition is met, it merges the groups together.

    Args:
        anchor_r (int): The row index of the anchor piece.
        anchor_c (int): The column index of the anchor piece.
        new_x (float): The new x-coordinate of the anchor piece on the screen.
        new_y (float): The new y-coordinate of the anchor piece on the screen.

    Returns:
        dict: The updated game state containing the new pieces and wishlists.
    """
    
    # Read the current state from the file:
    state = load_state()
    
    pW = state["pW"] # pW (float): The pixel width of a single piece
    pH = state["pH"] # pH (float): The pixel height of a single piece
    
    piece_to_group = get_piece_to_group_map(state["pieces"])
    moved_group_id = piece_to_group.get(f"{anchor_r},{anchor_c}")
    
    # Update the position of the group that moved
    state["pieces"] = update_group_position(
        state["pieces"], 
        moved_group_id, 
        new_x, new_y, 
        anchor_r, anchor_c
    )

    current_wishlist = state["wishlists"][moved_group_id]
    
    # Retrieve the list of pieces in the moved group from the state to inspect coordinates:
    moved_group = state["pieces"][moved_group_id]
    
    # Define a dynamic snap threshold (e.g., 8% of the piece width, minimum 15px)
    snap_threshold = max(15.0, pW * 0.08)
    
    for candidate in current_wishlist:
        candidate_r = candidate[0]
        candidate_c = candidate[1]
        
        # Calculate where the candidate should be relative to our moved group:
        candidate_ideal_x, candidate_ideal_y = get_candidate_ideal_coords(
            candidate_r,
            candidate_c,
            moved_group,
            pW,
            pH
        )
        
        # Find who owns the candidate and where it actually is:
        neighbor_group_id = piece_to_group.get(f"{candidate_r},{candidate_c}")
        
        # Look into that neighbor group to find the piece's current x, y
        neighbor_group = state["pieces"][neighbor_group_id]

        actual_piece = next(
            p for p in neighbor_group 
            if p["r"] == candidate_r and p["c"] == candidate_c
        )
        
        candidate_actual_x = actual_piece["x"]
        candidate_actual_y = actual_piece["y"]

        # Check if the distance between (Ideal) and (Actual) is small:
        dx = abs(candidate_ideal_x - candidate_actual_x)
        dy = abs(candidate_ideal_y - candidate_actual_y)
        
        # If close enough, perform the snap:
        if dx < snap_threshold and dy < snap_threshold:
            # SNAP! We found a match.
            neighbor_id = neighbor_group_id
            
            # Perform the snap:
            state = merge_groups(
                state, 
                moved_group_id, 
                neighbor_id, 
                candidate_ideal_x, 
                candidate_actual_x, 
                candidate_ideal_y, 
                candidate_actual_y
            )
            
            # Rebuild the lookup map and update the wishlist for the modified group:
            piece_to_group = get_piece_to_group_map(state["pieces"])
            
            # Update the wishlist because our group is now bigger:
            current_wishlist = state["wishlists"][moved_group_id]
            
            # Refresh the moved_group reference to get the newly added pieces:
            moved_group = state["pieces"][moved_group_id]
            
            # Stop searching after the first snap to enforce the 
            # "one mouse move, one snap" approach and prevent unintended cascades.
            break
        

    # Save the updated state and return:
    save_state(state)
    return state

def merge_groups(state, moved_id, neighbor_id, ideal_x, actual_x, ideal_y, actual_y):
    """
    Merges a neighbor group into the moved group when a snap occurs.
    
    This function calculates the offset between the ideal snap coordinates and
    the actual coordinates of the neighbor piece, shifts the neighbor group
    to align perfectly, appends its pieces to the moved group, and updates the 
    wishlists by combining them and removing overlapping pieces.
    
    Args:
        state (dict): The current game state containing pieces and wishlists.
        moved_id (int or str): The ID of the group being moved/merged into.
        neighbor_id (int or str): The ID of the neighboring group to be merged.
        ideal_x (float): The target x-coordinate where the piece should snap.
        actual_x (float): The current x-coordinate of the candidate piece.
        ideal_y (float): The target y-coordinate where the piece should snap.
        actual_y (float): The current y-coordinate of the candidate piece.
        
    Returns:
        dict: The updated game state.
    """
    
    # How much do we need to shift the neighbor to make it perfect?
    shift_x = ideal_x - actual_x
    shift_y = ideal_y - actual_y
    
    # After the player moved the group to a "close enough" position,
    # the computer must "teleport" the neighbor group so it perfectly aligns with our group
    # Move every piece in the neighbor group to its "perfect" spot
    for piece in state["pieces"][neighbor_id]:
        piece["x"] += shift_x
        piece["y"] += shift_y


    # Move the pieces from the neighbor sub-list into our current sub-list
    state["pieces"][moved_id].extend(state["pieces"][neighbor_id])
    
    # Update the internal group_id key for all pieces in the new group
    for piece in state["pieces"][moved_id]:
        piece["group_id"] = moved_id
    
    state["pieces"][neighbor_id] = []
    
    # Combine the wishlists and remove pieces that are now 'inside'
    new_wishlist = merge_wishlists(
        state["wishlists"][moved_id], 
        state["wishlists"][neighbor_id], 
        state["pieces"][moved_id]
    )
    state["wishlists"][moved_id] = new_wishlist
    state["wishlists"][neighbor_id] = []
    
    return state

def get_candidate_ideal_coords(candidate_r, candidate_c, moved_group, pW, pH):
    """
    Calculates the ideal screen coordinates for a candidate neighbor piece.

    This function searches the moved group to find a piece adjacent to the candidate 
    position (r, c). Based on the relative direction (North, South, East, or West) 
    between the adjacent piece and the candidate, it computes and returns the expected
    absolute screen coordinates (x, y) where the candidate should be located to snap.

    Args:
        candidate_r (int): The row index of the candidate piece.
        candidate_c (int): The column index of the candidate piece.
        moved_group (list of dicts): The list of pieces currently in the moved group.
        pW (float): The pixel width of a single piece.
        pH (float): The pixel height of a single piece.

    Returns:
        tuple of (float, float) or (None, None): The ideal (x, y) coordinates of the 
                                                candidate, or (None, None) if no adjacent 
                                                piece is found in the moved group.
    """
    for piece in moved_group:
        pr, pc = piece["r"], piece["c"]
        
        # Is this piece the Northern neighbor of the candidate?
        if pr == candidate_r - 1 and pc == candidate_c:
            return piece["x"], piece["y"] + pH
            
        # Is this piece the Southern neighbor?
        if pr == candidate_r + 1 and pc == candidate_c:
            return piece["x"], piece["y"] - pH
            
        # Is this piece the Western neighbor?
        if pr == candidate_r and pc == candidate_c - 1:
            return piece["x"] + pW, piece["y"]
            
        # Is this piece the Eastern neighbor?
        if pr == candidate_r and pc == candidate_c + 1:
            return piece["x"] - pW, piece["y"]
            
    return None, None

def update_group_position(scrambled, moved_group_id, new_x, new_y, anchor_r, anchor_c):
    """
    Updates the screen positions of all pieces in a group.

    This function locates the group corresponding to the given group ID,
    identifies the anchor piece within it, and calculates the required offset (delta). 
    It then applies this movement delta to all pieces in the group to update their 
    (x, y) coordinates.

    Args:
        scrambled (list): The master list of groups containing the pieces.
        moved_group_id (int or str): The ID of the group being moved.
        new_x (float): The new x-coordinate of the anchor piece on the screen.
        new_y (float): The new y-coordinate of the anchor piece on the screen.
        anchor_r (int): The row index of the anchor piece.
        anchor_c (int): The column index of the anchor piece.

    Returns:
        list: The updated scrambled list of groups.
    """
    # Find the group and the anchor piece's old position
    target_group = None
    for group in scrambled:
        # If a group becomes empty, group[0] will cause an error.
        # Just peek at the very first piece (index 0) in the sublist to see which group it is.
        if group and group[0]["group_id"] == moved_group_id:
            target_group = group
            break
            
    if not target_group:
        return scrambled

    # Calculate how much the anchor piece moved (the delta)
    # Find the anchor piece inside the group
    anchor_piece = next(p for p in target_group if p["r"] == anchor_r and p["c"] == anchor_c)
    dx = new_x - anchor_piece["x"]
    dy = new_y - anchor_piece["y"]

    # Update every piece in the moved group
    for piece in target_group:
        piece["x"] += dx
        piece["y"] += dy

    return scrambled

def merge_wishlists(wishlist_a, wishlist_b, new_group_pieces):
    """
    Merges two wishlists and removes positions that are now inside the group.

    When two groups are joined, this function combines their individual wishlists.
    It then filters out any coordinates that belong to pieces now part of the new, 
    merged group to ensure the engine does not attempt to snap to internal pieces.

    Args:
        wishlist_a (list of lists): The [r, c] coordinates of potential snapping neighbors for group A.
        wishlist_b (list of lists): The [r, c] coordinates of potential snapping neighbors for group B.
        new_group_pieces (list of dicts): The actual pieces currently residing in the newly combined group.

    Returns:
        list of lists: The updated, filtered list of unique [r, c] candidate coordinates.
    """
    # 1. Turn the coordinates into "tuples" so we can use Sets
    # (Sets can't hold lists, but they can hold tuples)
    set_a = {tuple(coord) for coord in wishlist_a}
    set_b = {tuple(coord) for coord in wishlist_b}
    
    # 2. Combine them (Union)
    combined = set_a.union(set_b)
    
    # 3. Create a set of all (r, c) that are now INSIDE the group
    inner_pieces = {(p["r"], p["c"]) for p in new_group_pieces}
    
    # 4. Subtract the inner pieces from the wishlist
    # "If it's inside the group, it's no longer a candidate for snapping"
    final_set = combined - inner_pieces
    
    # 5. Convert back to a list of lists for JSON compatibility
    return [list(coord) for coord in final_set]


def get_piece_to_group_map(scrambled):
    """
    Creates a mapping from piece coordinates to their current group ID.
    
    This function scans the scrambled list of groups and creates a 
    lookup dictionary where keys are stringified coordinates 'r,c' 
    and values are the corresponding group IDs. This eliminates the 
    need to search through the entire board when checking neighbors.
    
    Args:
        scrambled (list): The list of groups, where each group contains pieces.
        
    Returns:
        dict: A dictionary with 'r,c' as keys and the group_id (int) as values.
    """
    piece_to_group = {}
    
    # 'enumerate' gives us the index (group_id) and the content (group)
    for group_id, group in enumerate(scrambled):
        
        # Now we look at every piece inside that specific group
        for piece in group:
            
            # We create a coordinate label like "0,1"
            coord_key = f"{piece['r']},{piece['c']}"
            
            # We record: "This coordinate belongs to this group index"
            piece_to_group[coord_key] = group_id
            
    return piece_to_group